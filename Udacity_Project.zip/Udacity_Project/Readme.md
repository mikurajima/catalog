# Udacity Fullstack Project 1
This is an assigned project by Udacity that is for fullstack web developer nanodegree program.
## Installation
Place takeshi.py and newsdata.sql at your vagrant holder.  
vagrant is not working where the holder name uses Chinese character (Kanji).  
At windows, please turn off hypervisor auto start, otherwise vagrant is not working.
## Usage
run `python3 takeshi.py`
## Contributing
[virtual box](https://download.virtualbox.org/virtualbox/6.0.10/VirtualBox-6.0.10-132072-Win.exe)
[vagrant](https://www.vagrantup.com/downloads.html)
[vagrant configuration file (fork from GitHub)](https://github.com/udacity/fullstack-nanodegree-vm)
[newsdata.sql](https://d17h27t6h515a5.cloudfront.net/topher/2016/August/57b5f748_newsdata/newsdata.zip)
## Code Status
Build
## License
