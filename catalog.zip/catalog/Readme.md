# Udacity Fullstack Project 2
This is an assigned project 2nd by Udacity that is for fullstack web developer nanodegree program.
It is a catalog web application that allows user CURD items and cetegory with OAuth
## Installation
Place this folder at your vagrant holder.  
vagrant is not working where the holder name uses Chinese character (Kanji).  
At windows, please turn off hypervisor auto start, otherwise vagrant is not working.
## Usage
run `python3 application.py`
access `localhost:5000/` to start
## Contributing
[virtual box](https://download.virtualbox.org/virtualbox/6.0.10/VirtualBox-6.0.10-132072-Win.exe)
[vagrant](https://www.vagrantup.com/downloads.html)
[vagrant configuration file (fork from GitHub)](https://github.com/udacity/fullstack-nanodegree-vm)
## Code Status
Build
## License
